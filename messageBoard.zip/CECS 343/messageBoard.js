tinymce.init({
  selector: "textarea"
	
});